package com.example.moviemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.moviemanager.databinding.MovieFormFragmentBinding

class MovieFormFragment : Fragment() {
    private var _binding : MovieFormFragmentBinding?= null

    private val binding get() = _binding!!
    private val viewModel: MovieFormViewModel by viewModels()
    private var imageUri: Uri? = null
    val pickImageLauncher : ActivityResultLauncher<Array<String>> = registerForActivityResult(ActivityResultContracts.OpenDocument()){
        binding.imageViewPoster.setImageURI(it)
        requireActivity().contentResolver.takePersistableUriPermission(it!!,Intent.FLAG_GRANT_READ_URI_PERMISSION)
        imageUri = it
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       _binding = MovieFormFragmentBinding.inflate(inflater,container,false)
        binding.buttonSave.setOnClickListener {
            findNavController().navigate(R.id.action_movieFormFragment_to_allMovieListFargment)
        }
        binding.buttonCancel.setOnClickListener {
            findNavController().navigate(R.id.action_movieFormFragment_to_allMovieListFargment)
        }
        binding.buttonSelectImage.setOnClickListener {
            pickImageLauncher.launch(arrayOf("image/*"))
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    private fun setupObservers() {
        viewModel.title.observe(viewLifecycleOwner) { title ->
            binding.editTextTitle.setText(title)
        }

        viewModel.year.observe(viewLifecycleOwner) { year ->
            binding.editTextYear.setText(year)
        }

        viewModel.genre.observe(viewLifecycleOwner) { genre ->
            binding.editTextGenre.setText(genre)
        }

        viewModel.description.observe(viewLifecycleOwner) { description ->
            binding.editTextDiscreption.setText(description)
        }

        viewModel.posterUri.observe(viewLifecycleOwner) { uri ->
            binding.imageViewPoster.setImageURI(uri)
        }
    }

    private fun setupListeners() {
        binding.buttonSave.setOnClickListener {
            //  update database, navigate back
            val movie = Movie(
                image = viewModel.posterUri.value?.toString(),
                title = binding.editTextTitle.text.toString(),
                year = binding.editTextYear.text.toString(),
                genre = binding.editTextGenre.text.toString(),
                description = binding.editTextDiscreption.text.toString()
            )
            ItemManager.add(movie)
            findNavController().navigate(R.id.action_movieFormFragment_to_allMovieListFargment)
        }

        binding.buttonCancel.setOnClickListener {
            viewModel.clearForm()
            findNavController().navigate(R.id.action_movieFormFragment_to_allMovieListFargment)
        }

        binding.buttonSelectImage.setOnClickListener {
            pickImageLauncher.launch(arrayOf("image/*"))
        }

        binding.editTextTitle.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) viewModel.setTitle(binding.editTextTitle.text.toString())
        }

        binding.editTextYear.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) viewModel.setYear(binding.editTextYear.text.toString())
        }

        binding.editTextGenre.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) viewModel.setGenre(binding.editTextGenre.text.toString())
        }

        binding.editTextDiscreption.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) viewModel.setDescription(binding.editTextDiscreption.text.toString())
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}