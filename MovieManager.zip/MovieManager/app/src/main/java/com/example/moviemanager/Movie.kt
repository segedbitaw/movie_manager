package com.example.moviemanager

data class Movie(val image: String?,val title:String,val year: String,val genre: String,val description: String) {
}
object ItemManager{
    val items: MutableList<Movie> = mutableListOf()

    fun add(item: Movie){
        items.add(item)
    }

    fun remove(index:Int){
        items.removeAt(index)
    }

}